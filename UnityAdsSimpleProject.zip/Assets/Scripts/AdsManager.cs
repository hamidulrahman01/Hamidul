using UnityEngine;
using UnityEngine.Advertisements;

public class AdsManager : MonoBehaviour
{
    private string gameId = "5787200"; // তোমার Game ID
    private bool testMode = true; // টেস্ট মোড চালু থাকবে

    void Start()
    {
        Advertisement.Initialize(gameId, testMode);
    }

    public void ShowAd()
    {
        if (Advertisement.IsReady())
        {
            Advertisement.Show();
        }
        else
        {
            Debug.Log("Ad not ready yet");
        }
    }
}
