
Unity Simple Ads Project

1. Open the project in Unity.
2. Create a new Scene or open the existing one.
3. Create a Button UI element.
4. Create an empty GameObject and attach the "AdsManager" script.
5. Set the Button's OnClick() event to call AdsManager.ShowAd().
6. Make sure you have Unity Ads service enabled from Services tab.

Game ID used: 5787200
Test Mode: Enabled
